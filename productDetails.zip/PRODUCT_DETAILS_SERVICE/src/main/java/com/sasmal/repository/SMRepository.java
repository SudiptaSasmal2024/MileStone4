package com.sasmal.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.sasmal.entities.SMEntity;


@Repository
public interface SMRepository extends JpaRepository<SMEntity, Integer>{
	Optional<SMEntity> findByType(String type);

}

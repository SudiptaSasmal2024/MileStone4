package com.product.Service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.product.Entity.ProductDetailsEntity;
import com.product.Repository.ProductDetailsRepository;



@Service
public class ProductDetailsService {

	@Autowired
	private ProductDetailsRepository repository;
	
	public Optional<ProductDetailsEntity> getbyId(Integer id) {
		return repository.findById(id);
	}
	
	
	
	public ProductDetailsEntity addProduct(ProductDetailsEntity entity) {
		return repository.save(entity);
	}
	public List<ProductDetailsEntity> getAll() {
		return repository.findAll();
	}
}

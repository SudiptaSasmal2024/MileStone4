package com.sasmal.service;

import java.util.Optional;

import com.sasmal.entities.SMEntity;

public interface SMService {
	
	SMEntity create(SMEntity smEntity);
	Optional<SMEntity> getOne(Integer id);
	Optional<SMEntity> getByType(String type);
	
//	List<DepartmentEntity> getAll();

}
